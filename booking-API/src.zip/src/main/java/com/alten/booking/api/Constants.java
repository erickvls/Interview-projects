package com.alten.booking.api;

public class Constants {
    public static final int STAY_LIMIT = 3;
    public static final int BOOKING_LIMIT_IN_ADVANCE = 30;
    public static final String DATE_FORMAT = "yyyy-MM-dd";
}
