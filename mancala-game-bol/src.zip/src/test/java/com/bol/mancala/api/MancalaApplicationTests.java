package com.bol.mancala.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MancalaApplicationTests {

	@Test
	void contextLoads() {
	}

}
